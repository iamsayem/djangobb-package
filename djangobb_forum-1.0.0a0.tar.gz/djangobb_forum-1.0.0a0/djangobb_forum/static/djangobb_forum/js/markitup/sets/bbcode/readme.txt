Markup language: 
BBCode

Description:
A basic BBCode markup set with Bold, Italic, Underline, Picture, Link, Size, List, Quotes, Code, Clean button, Preview button.

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css