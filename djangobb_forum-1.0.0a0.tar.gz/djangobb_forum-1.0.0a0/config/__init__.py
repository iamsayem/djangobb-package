"""
    Created by Sayem on 18 January, 2020
"""

from .apps import INSTALLED_APPS as PROJECT_APPS

__author__ = "sayem"

__all__ = [
    "PROJECT_APPS"
]
