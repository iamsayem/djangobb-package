"""
    Created by Sayem on 18 January, 2020
"""

__author__ = "sayem"

INSTALLED_APPS = [
    "djangobb_forum"
]
